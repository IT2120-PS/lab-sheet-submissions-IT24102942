# Set working directory
setwd("C:\\Users\\IT24102942\\Desktop\\IT24102942")
getwd()

data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

#q1 mean and variance for data
popmn<-mean(Weight.kg.)
popsd<-sd(Weight.kg.)

samples <- matrix(nrow = 5, ncol = 0) 

n <- c()

for(i in 1:25){
  s <- sample(Weight.kg., 6, replace = TRUE)   # Take a sample of 5 values
  samples <- cbind(samples, s)              # Add sample as a new column
  n <- c(n, paste('S', i, sep = ''))        # Create sample name like "S1", "S2", ...
}

# Assign column names to the matrix
colnames(samples) <- n

s.means<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)

samplemean<-mean(s.means)
samplevars<-var(s.means)

popmn
samplemean

truevar = popvar/5
samplevars